Author
------
- Steven Myint (https://github.com/myint)

Patches
-------
- 王昌旭 (https://github.com/DelightRun)
- LCD 047 (https://github.com/lcd047)
- uralbash (https://github.com/uralbash)
- Michael Fladischer (https://github.com/fladi)
- biscuitsnake (https://github.com/biscuitsnake)
- Maël Pedretti (https://github.com/73VW)
- Santos Gallegos (https://github.com/stsewd)
